LUMEN — progetto Android

Questo progetto incapsula il file HTML originale in una WebView Android e carica
il gioco localmente, senza bisogno di un sito web. Il file originale è in:
app/src/main/assets/index.html

Come creare l'APK:
1. Installa Android Studio su Windows, macOS o Linux.
2. Apri Android Studio e scegli "Open", selezionando la cartella LumenAndroid.
3. Attendi il completamento della sincronizzazione Gradle e installa i componenti
   SDK richiesti se Android Studio lo chiede.
4. Seleziona Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio mostrerà il percorso dell'APK generato (di solito
   app/build/outputs/apk/debug/app-debug.apk).

Nota:
- Questo archivio è il progetto sorgente Android, non un APK già compilato.
- Il gioco HTML è incluso così come ricevuto.
- Le funzioni multiplayer Bluetooth che richiedono un bridge nativo Android
  dedicato non sono implementate in questa versione wrapper; le funzioni WebRTC
  basate su codice restano parte del codice HTML originale.
